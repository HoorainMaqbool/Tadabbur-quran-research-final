import Icons from '../components/Icons';

const cards=[
  ['research','01','Quran Research','Ask a focused Quran-related question and receive a source-grounded response.','Explore research','/research'],
  ['spark','02','Topic Explorer','Explore a Quranic theme through relevant ayahs and thematic synthesis.','Explore a theme','/topics'],
  ['book','03','Ayah Deep Dive','Study one specific ayah with Arabic, translation, explanation and reflection.','Open an ayah','/deep-dive']
];

export default function Home({navigate}){
  return <>
    <section className="home-hero">
      <div className="hero-img"/>
      <div className="hero-wash"/>
      <div className="hero-content">
        <span className="eyebrow light">QURAN · RESEARCH · REFLECTION</span>
        <h1>A quieter way to<br/><em>study the Quran.</em></h1>
        <p>Tadabbur brings research, thematic exploration and ayah study into one calm space.</p>
        <button className="btn gold" onClick={()=>navigate('/research')}>
          Begin a study <Icons name="arrow" size={17}/>
        </button>
      </div>
    </section>

    <section className="home-intro">
      <div>
        <span className="eyebrow">The Tadabbur study space</span>
        <h2>Choose how you want to engage.</h2>
        <p>Each path has one clear purpose. Your selected feature stays active until you explicitly choose another.</p>
      </div>

      <div className="home-grid">
        {cards.map(([icon,n,t,d,a,to])=>
          <button key={to} className="home-card" onClick={()=>navigate(to)}>
            <span className="card-num">{n}</span>
            <span className="card-icon"><Icons name={icon}/></span>
            <span className="card-copy">
              <h3>{t}</h3>
              <p>{d}</p>
              <span className="card-link">{a}<Icons name="arrow" size={14}/></span>
            </span>
          </button>
        )}
      </div>
    </section>

    <section className="promise">
      <span className="seal-mini">ت</span>
      <div>
        <strong>Source discipline, built in.</strong>
        <p>Quran Arabic, Sahih International translation, and AI-generated explanation are presented as different content types.</p>
      </div>
    </section>
  </>
}
