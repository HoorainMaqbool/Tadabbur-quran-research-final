import {useState} from 'react';
import Icons from './Icons';

const links=[
  ['Research','/research'],
  ['Topics','/topics'],
  ['Deep Dive','/deep-dive']
];

export default function Topbar({path,navigate}){
  const[open,setOpen]=useState(false);

  function go(to){
    setOpen(false);
    navigate(to);
  }

  return <header className="topbar">
    <button className="brand" onClick={()=>go('/')}>
      <img src="/assets/tadabbur-seal.png" alt="Tadabbur"/>
      <span>
        <strong>Tadabbur</strong>
        <small>Quran Research & Reflection</small>
      </span>
    </button>

    <nav>
      {links.map(([label,to])=>
        <button key={to} className={path===to?'active':''} onClick={()=>go(to)}>
          {label}
        </button>
      )}
    </nav>

    <div className="topbar-actions">
      <button className="icon-btn menu-toggle" onClick={()=>setOpen(!open)} aria-label="Open navigation">
        <Icons name={open?'close':'menu'}/>
      </button>
      <button className="language-pill" title="Language is selected inside each feature">
        EN <Icons name="chev" size={14}/>
      </button>
    </div>

    {open&&<div className="mobile-nav">
      {links.map(([label,to])=>
        <button key={to} className={path===to?'active':''} onClick={()=>go(to)}>
          {label}<Icons name="arrow" size={14}/>
        </button>
      )}
    </div>}
  </header>
}
