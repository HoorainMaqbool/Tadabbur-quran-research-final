import {useState} from 'react';
import FeatureIntro from '../components/FeatureIntro';
import {Loading,ErrorBox,BackendResponse} from '../components/Feedback';
import AyahCard from '../components/AyahCard';
import SourceStrip from '../components/SourceStrip';
import {callFeature} from '../lib/api';
import Icons from '../components/Icons';

export default function Research(){
  const [q,setQ]=useState('');
  const [lang,setLang]=useState('en');
  const [response,setResponse]=useState(null);
  const [err,setErr]=useState(null);
  const [loading,setLoading]=useState(false);
  async function go(e){
    e.preventDefault();
    if(!q.trim())return;
    setLoading(true);setErr(null);setResponse(null);
    try{setResponse(await callFeature('research',{requested_feature:'research',question:q.trim(),language:lang}))}
    catch(x){setErr(x)}finally{setLoading(false)}
  }
  const data=response?.data;
  const candidate=data?.results||data?.ayahs||data?.relevant_ayahs||[];
  const arr=Array.isArray(candidate)?candidate:[];
  return <section className="page">
    <FeatureIntro number="01" label="Research" title="Quran Research" text="A focused research space for general Quran-related questions. The research workflow remains responsible for retrieval and evidence validation."/>
    <form className="soft-form" onSubmit={go}>
      <textarea rows="4" value={q} onChange={e=>setQ(e.target.value)} placeholder="What guidance does the Quran give about patience during hardship?"/>
      <div className="form-row"><select value={lang} onChange={e=>setLang(e.target.value)}><option value="en">English</option><option value="ur">Urdu</option><option value="roman_ur">Roman Urdu</option></select><button className="btn green" disabled={loading}>{loading?'Researching…':'Research'} <Icons name="arrow" size={16}/></button></div>
    </form>
    {loading&&<Loading>Retrieving Quran evidence…</Loading>}
    {err&&<><ErrorBox message={err.message}/><BackendResponse error={err}/></>}
    {response&&!loading&&!err&&<>
      {data&&typeof data==='object'&&<div className="answer-area">{(data.ai_explanation||data.summary)&&<div className="lead-answer"><span className="eyebrow">AI-generated synthesis</span><h2>{data.summary||'Grounded Quran research'}</h2>{data.ai_explanation&&<p>{data.ai_explanation}</p>}</div>}{arr.map((x,i)=><AyahCard key={x.ayah_reference||i} ayah={x}/>)}<SourceStrip sources={data.sources||arr.map(x=>x.ayah_reference)} guard={data.evidence_guard}/></div>}
      <BackendResponse response={response}/>
    </>}
  </section>
}
